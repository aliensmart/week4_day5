from app.account import Account


def run():
    pass


"""
Sample execution
Welcome to Terminal Trader!
    
    1. create account
    2. login
    3. quit
Your choice: 2

Main Menu:
    1. see balance & positions
    2. deposit money
    3. look up stock price
    4. buy stock
    5. sell stock
    6. trade history
etc.
you should have useful output if a user inputs a stock that does not exist
you should not allow a user to spend money they don't have or sell
shares they don't have
your display of positions or trades should be well-formatted, don't
just print a python list


account = Account.login(username, password)
if account:
    mainmenu(account)
"""